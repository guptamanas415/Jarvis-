---
name: JARVIS-Inspired Interface
colors:
  surface: '#0c1322'
  surface-dim: '#0c1322'
  surface-bright: '#323949'
  surface-container-lowest: '#070e1d'
  surface-container-low: '#141b2b'
  surface-container: '#191f2f'
  surface-container-high: '#232a3a'
  surface-container-highest: '#2e3545'
  on-surface: '#dce2f7'
  on-surface-variant: '#c6c6cc'
  inverse-surface: '#dce2f7'
  inverse-on-surface: '#293040'
  outline: '#909096'
  outline-variant: '#45474c'
  surface-tint: '#c1c6d7'
  primary: '#c1c6d7'
  on-primary: '#2b303d'
  primary-container: '#030712'
  on-primary-container: '#737887'
  inverse-primary: '#595e6c'
  secondary: '#dcfdff'
  on-secondary: '#00373a'
  secondary-container: '#00f1fd'
  on-secondary-container: '#006a6f'
  tertiary: '#9bcbff'
  on-tertiary: '#003256'
  tertiary-container: '#000814'
  on-tertiary-container: '#007dc9'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dde2f3'
  primary-fixed-dim: '#c1c6d7'
  on-primary-fixed: '#161c28'
  on-primary-fixed-variant: '#414754'
  secondary-fixed: '#6ff6ff'
  secondary-fixed-dim: '#00dce6'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f53'
  tertiary-fixed: '#d0e4ff'
  tertiary-fixed-dim: '#9bcbff'
  on-tertiary-fixed: '#001d34'
  on-tertiary-fixed-variant: '#004a7a'
  background: '#0c1322'
  on-background: '#dce2f7'
  surface-variant: '#2e3545'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0.05em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.15em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers an elite, high-performance sci-fi interface designed for maximum cognitive efficiency and futuristic luxury. The persona is authoritative, intelligent, and precision-engineered. 

The aesthetic marries **Glassmorphism** and **High-Contrast Modernism**, leveraging deep obsidian canvases, razor-sharp translucent layers, and luminous neon accents to create a multi-dimensional depth. The visual tone is calm yet hyper-responsive, evoking high-tech command centers and next-generation operating systems.

## Colors

The palette is anchored in absolute darkness, utilizing deep obsidian and space black to maximize contrast for luminous data displays.

- **Primary Canvas:** `#030712` (Deep Obsidian)
- **Surface Elevation:** `#0b0f19` (Dark Navy Black)
- **Primary Accent:** `#00f2fe` (Electric Cyan)
- **Secondary Accent:** `#4facfe` (Neon Blue)
- **Tertiary Accent:** `#06b6d4` (Cyan Subdued)
- **Text Primary:** `#f8fafc` (Slate 50)
- **Text Secondary:** `#94a3b8` (Slate 400)
- **Borders / Glows:** `rgba(0, 242, 254, 0.3)`

## Typography

The typographic hierarchy pairs geometric, high-tech display forms with ultra-legible utilitarian body copy. 

- **Headlines & Labels:** Uses **Space Grotesk** for its precise geometric letterforms and futuristic edge. Uppercase styling with wide letter-spacing (`0.1em` to `0.15em`) is utilized for telemetry, system readouts, and navigation.
- **Body & Data:** Uses **Inter** to ensure maximum legibility across dense analytics, logs, and conversational prompts at small scales.

## Layout & Spacing

The layout philosophy follows a strict **Fluid Grid** architecture optimized for command-line dashboards and holographic viewports. 

- **Grid System:** 12-column flexible grid with 24px (`1.5rem`) gutters and generous 32px (`2rem`) outer canvas margins to maintain an uncluttered field of view.
- **Responsive Behavior:** On desktop, panels dock seamlessly into a multi-column HUD layout. On tablet and mobile, the grid reflows into a single-column stacked data feed, collapsing non-essential telemetry drawers behind toggleable triggers.
- **Rhythm:** Spacing follows a modular scale emphasizing tight grouping for related data points (`0.25rem`–`0.5rem`) and structural breathing room (`1.5rem`–`2.5rem`) between primary system modules.

## Elevation & Depth

Depth is established through **Glassmorphism and Ambient Glows** rather than physical drop shadows. 

- **Translucent Layers:** Surfaces utilize dark semi-transparent fills (`rgba(11, 15, 25, 0.65)`) paired with heavy backdrop filters (`blur(16px)`) to mimic advanced holographic glass.
- **Luminous Outlines:** Elements are defined by low-opacity electric cyan borders (`rgba(0, 242, 254, 0.25)`) that intensify to full opacity (`rgba(0, 242, 254, 0.9)`) on hover or active states, radiating a subtle neon bloom.
- **Z-Axis Hierarchy:** Background canvases sit at absolute zero; floating HUD panels, modal readouts, and active system notifications elevate via stacked blur layers and inner accent glows.

## Shapes

The shape language is strictly **Soft/Geometric** (`roundedness` level 1), utilizing subtle 0.25rem corner radii (`0.5rem` for large containers) paired with clipped 45-degree corner notches on primary command cards. This mechanical precision avoids overly soft organic curves, reinforcing the engineered, sci-fi aesthetic.

## Components

- **Buttons:** Primary actions feature a glowing electric cyan border, subtle backdrop blur, and an internal linear gradient from `00f2fe` to `4facfe` at low opacity, shifting to full opacity on hover with a crisp outward glow. Secondary actions use ghost borders with text in uppercase Space Grotesk.
- **Chips & Tags:** Compact pill-like or notched micro-containers displaying system statuses (e.g., "SYSTEM: ONLINE"). Styled with a `1px` cyan border, 8px horizontal padding, and glowing status indicator dots.
- **Lists:** Clean data rows separated by 1px hairline dividers (`rgba(255,255,255,0.06)`). Hover states trigger an immediate left-border accent highlight and subtle background brightening.
- **Checkboxes & Radio Buttons:** Custom geometric squares and diamonds. Unchecked states show a dim cyan outline; checked states fill with solid electric cyan and project a sharp inner point or check glyph.
- **Input Fields:** Embedded obsidianwells (`#0b0f19`) featuring a persistent bottom or full-perimeter glowing border that shifts from neutral slate to vibrant cyan upon focus. Include monospace helper text for telemetry or command entry.
- **Cards (HUD Panels):** Glassmorphic containers featuring corner accent ticks, a top title bar with uppercase tracking, and a subtle scanning line animation on load.
- **Telemetry Readouts & Progress Bars:** Multi-segmented progress lines and circular gauges utilizing glowing gradients that pulsate during active data processing.